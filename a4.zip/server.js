
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

let selectedProduct = null;

app.use(express.static(path.join(__dirname, 'src')));
app.use(express.static(path.join(__dirname, 'images')));
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});

app.get('/api/products', (req, res) => {
    res.json({ processor: { name: 'AMD Ryzen 7 5800XT 8 Core Desktop Processor',
                            price: '$399.99',
                            image: 'amdryzen77800x.jpg' },
                motherboard: { name: 'ASUS ROG Strix B550-F Gaming (Wi-Fi 6) ATX Motherboard',
                              price: '$199.99',
                              image: 'asusrogstrixb550f.jpg' },
                memory: { name: 'Corsair Vengeance LPX 16GB (2 x 8GB) DDR4-3200 Memory',
                          price: '$79.99',
                          image: 'corsairvengeancelpx16gb.jpg' },
                gpu: {  name: 'MSI GeForce RTX 3060 Ti GAMING X TRIO 8GB Video Card',
                        price: '$499.99',
                        image: 'msigeforcerxt3060tigamingxtrio8gb.jpg'}
            });
     });

app.post('/api/select-product', (req, res) => { 
    selectedProduct = req.body;
    console.log('Prodcut Data Received:', selectedProduct);
    res.json({ message: `Selected Product ${selectedProduct}` });
});

app.get('/api/selected-products', (req, res) => {
    res.json(selectedProduct);
});

app.post('/api/submit-order', (req, res) => { 
    const orderData = req.body;
    console.log('Order Data Received:', orderData);
    res.json({ message: "Your item will be delivered soon." });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});