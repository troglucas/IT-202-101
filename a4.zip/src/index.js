
//when document is ready
$(document).ready(function() {
    //ajax call to get products
    $.get('/api/products', function(data) {
        $("#product1").text(data.processor.name);
        $("#product2").text(data.motherboard.name);
        $("#product3").text(data.memory.name);
        $("#product4").text(data.gpu.name);
        const products = [data.processor, data.motherboard, data.memory, data.gpu];

    }).fail(function() { 
        $("#")
    });
});